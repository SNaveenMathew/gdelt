library(lubridate)
library(RSQLite)
library(sqldf)
library(ggplot2)
library(grid)
library(ggmap)
library(mapproj)
library(countrycode)
library(dplyr)
library(gdeltr)
library(reshape2)
library(scales)
library(extrafont)
library(RgoogleMaps)
library(plyr)

setwd("C:/Users/naveen.nathan/Desktop/Competition/TEXATA/Round 2/")
options(stringsAsFactors = F)
temp1 <- read.csv("20171008.export.csv", sep = "\t", header = F)
temp2 <- read.csv("20171008.gkg_.csv", sep = "\t", header = T)

temp2$QuadClass <- as.character(
  sapply(strsplit(temp2$LOCATIONS, "#"), function(u) u[1]))
temp2$GoldsteinScale <- as.numeric(sapply(strsplit(temp2$TONE, ","),
                                          function(u)
                                            # mean(as.numeric(u), na.rm = T))
                                            u[1]))
# colnames(temp2) <- c("Day", "Actor1Code", "Actor2Code", "EventCode", "QuadCategory", 
#                  "GoldsteinScale", "Actor1Geo_Lat", "Actor1Geo_Long", "Actor2Geo_Lat", "Actor2Geo_Long", 
#                  "ActionGeo_Lat", "ActionGeo_Long")
temp2$DATE <- ymd(temp2$DATE)

# Year wise split
x <- data.frame(table(year(temp2$DATE)))
ggplot(x, aes(x = Var1, y = Freq)) + geom_bar(stat = "identity") + theme_bw() + 
  theme(axis.text.x = element_text(angle = 90, hjust = 1))

locations <- strsplit(temp2$LOCATIONS, "#")
temp2$ActionGeo_Lat <- as.numeric(sapply(locations, function(u) u[5]))
temp2$ActionGeo_Long <- as.numeric(sapply(locations, function(u) u[6]))
#

temp2$count <- 1
df <- ddply(temp2, .(ActionGeo_Lat, ActionGeo_Long), summarize, count = sum(count))

# lets define the scope of our map
lat <- c(40, 70)
lon <- c(20, 100)
center = c(lat = mean(lat), lon = mean(lon))
zoom <- min(MaxZoom(range(lat), range(lon)))

# And download a map file!
map <- get_map(location = c(lon = mean(lon), lat = mean(lat)), zoom = 3, maptype = "terrain", 
               source = "google")
print(ggmap(map) + geom_point(data = df, aes(x = ActionGeo_Long, y = ActionGeo_Lat, 
                                             size = count), alpha = 0.3))
