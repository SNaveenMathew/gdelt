library(forecast)
library(lubridate)
library(ggplot2)
library(RgoogleMaps)

ncvTest.arima <- function(model, ...) {
  data <- getCall(model)$data
  model <- model
  sumry <- summary(model)
  residuals <- residuals(model)
  
  S.sq <- (length(residuals)-2)*(model$sigma2)/length(residuals)
  #cat("S.sq=",S.sq,"\n")
  .U <- (residuals^2)/S.sq
  #cat(".U=",.U,"\n")
  mod <- lm(.U ~ fitted.values(model))
  varnames <- "fitted.values"
  var.formula <- ~ fitted.values
  df <- 1
  SS <- anova(mod)$"Sum Sq"
  #cat("SS=",SS,"\n")
  RegSS <- sum(SS) - SS[length(SS)]
  Chisq <- RegSS/2
  result <- list(formula=var.formula, formula.name="Variance",ChiSquare=Chisq, Df=df, p=pchisq(Chisq, df, lower.tail=FALSE), test="Non-constant Variance Score Test")
  class(result) <- "chisqTest"
  result
} 

options(stringsAsFactors = F)
setwd("C:/Users/naveen.nathan/Desktop/Competition/TEXATA/Round 2")
event_monthyear <- read.csv("event_monthyear.csv")
event_monthyear <- event_monthyear[!is.na(event_monthyear$MonthYear),]
event_monthyear <- event_monthyear[order(event_monthyear$MonthYear, decreasing = F), ]
rownames(event_monthyear) <- NULL
ggplot(event_monthyear, aes(x = MonthYear, y = total)) + geom_bar(stat = "identity") +
  theme_bw() + theme(axis.text.x = element_text(angle = 90, hjust = 1))
tsr <- decompose(ts(event_monthyear$total, frequency = 12))
plot(tsr)
seas_model <- auto.arima(ts(event_monthyear$total, frequency = 12), seasonal = T)
plot(seas_model$residuals) # Heteroskedastic
ncvTest.arima(seas_model) # Confirmed heteroskedastic

non_seas_model <- auto.arima(ts(event_monthyear$total, frequency = 12), seasonal = F)
plot(non_seas_model$residuals) # Heteroskedastic
ncvTest.arima(seas_model) # Confirmed heteroskedastic

