# -*- coding: utf-8 -*-
"""
Created on Sat Oct 14 19:01:46 2017

@author: naveen.nathan
"""

import datetime as dt
from collections import defaultdict

import matplotlib.pyplot as plt
import pandas
from matplotlib import rcParams
from os import chdir

rcParams['figure.figsize'] = [8,4]
chdir("C:\\Users\\naveen.nathan\\Desktop\\Competition\\TEXATA\\Round 2")
monthly_data = defaultdict(int)
material_coop = defaultdict(int) 
material_conf = defaultdict(int)
verbal_coop = defaultdict(int)
verbal_conf = defaultdict(int)
data = []
count = 0
f = open("20171008.gkg_.csv", 'r')
next(f)
for row in f:
    try:
        row = row.split("\t")
#        actor1 = row[1][:3]
#        actor2 = row[2][:3]
#        both = actor1 + actor2
#        if "ISR" in both and ("PAL" in both or "PSE" in both):
#            year = int(row[0][:4])
#            month = int(row[0][4:6])
#            day = int(row[0][6:])
#            quad_cat = row[4]
#            data.append([year, month, day, actor1, actor2, quad_cat])
        row[4] = row[4].split("#")[0]
        date_str = row[0]
        year = int(date_str[:4])
        month = int(date_str[4:6])
        date = dt.datetime(year, month, 1)
        monthly_data[date] += 1
        count += 1
        if row[4] == '1':
            material_coop[date] += 1
        elif row[4] == '2':
            verbal_coop[date] += 1
        elif row[4] == '3':
            verbal_conf[date] += 1
        elif row[4] == '4':
            material_conf[date] += 1
        print(year)
    except:
        pass
f.close()

monthly_events = pandas.Series(monthly_data)
monthly_coop = pandas.Series(material_coop)
monthly_conf = pandas.Series(material_conf)
trends = pandas.DataFrame({"Material_Cooperation": monthly_coop,
                           "Material_Conflict": monthly_conf})
trends.plot()
monthly_events.plot()
ilpalcon = pandas.DataFrame(data, 
    columns=["Year", "Month", "Day", "Actor1", "Actor2", "QuadCat"])
ilpalcon.head()
pivot = pandas.pivot_table(ilpalcon, values="Day", rows=["Year", "Month"], cols="QuadCat", aggfunc=len)
pivot = pivot.fillna(0) # Replace any missing data with zeros
pivot = pivot.reset_index() # Make Year and Month regular columns
pivot.head()
get_date = lambda x: dt.datetime(year=int(x[0]), month=int(x[1]), day=1)
pivot["date"] = pivot.apply(get_date, axis=1)
pivot = pivot.set_index("date")
pivot = pivot[["1", "2", "3", "4"]]
pivot = pivot.rename(columns={"1": "Material Cooperation",
                              "2": "Verbal Cooperation",
                              "3": "Verbal Conflict",
                              "4": "Material Conflict"})
pivot["Peace_Index"] = (pivot["Material Cooperation"] 
                        + pivot["Verbal Cooperation"] 
                        - pivot["Verbal Conflict"]
                        - pivot["Material Conflict"])
pivot["Peace_Index"].plot(figsize=(8,4))