#' gdeltr
#'
#' @name gdeltr
#' @docType package
NULL
