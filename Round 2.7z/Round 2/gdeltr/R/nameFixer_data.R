#' Name translation dataframe for GKG 
#' 

#' 
#' \itemize{
#'   \item oldvalue: The name to be replaced 
#'   \item newvalue: The standard name form
#' }
#' 
#' @note This is a work in progress.
#' @docType data
#' @keywords datasets, gdelt, gdeltr
#' @name nameFixer_data 
#' @usage nameFixer_data
#' @format A data frame with a few dozen rows and 2 columns
NULL